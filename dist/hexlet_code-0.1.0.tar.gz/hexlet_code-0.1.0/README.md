### Hexlet tests and linter status:
[![Actions Status](https://github.com/kuznetsovyar22/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/kuznetsovyar22/python-project-50/actions)
[![action](https://github.com/kuznetsovyar22/python-project-50/actions/workflows/gendiff.yml/badge.svg)](https://github.com/kuznetsovyar22/python-project-50/actions/workflows/gendiff.yml)
<a href="https://codeclimate.com/github/kuznetsovyar22/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/5f10231f01da7479d1e9/maintainability" /></a>
<a href="https://codeclimate.com/github/kuznetsovyar22/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/5f10231f01da7479d1e9/test_coverage" /></a>
